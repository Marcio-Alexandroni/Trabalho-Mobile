import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PokemonPage(),
    );
  }
}

class PokemonPage extends StatefulWidget {
  const PokemonPage({super.key});

  @override
  State<PokemonPage> createState() => _PokemonPageState();
}

class _PokemonPageState extends State<PokemonPage> {
  String? _name;
  String? _imageUrl;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _getRandomPokemon(); // já carrega 1 ao abrir
  }

  Future<void> _getRandomPokemon() async {
    setState(() => _loading = true);

    final int id = Random().nextInt(151) + 1;;

    final uri = Uri.parse('https://pokeapi.co/api/v2/pokemon/$id');

    try {
      final response = await http.get(uri);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;

        setState(() {
          _name = data['name'] as String;
          _imageUrl = data['sprites']['front_default'] as String;
          _loading = false;
        });
      } else {
        setState(() {
          _name = 'Erro na API (${response.statusCode})';
          _imageUrl = null;
          _loading = false;
        });
      }
    } catch (e) {
      setState(() {
        _name = 'Erro: $e';
        _imageUrl = null;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pesquisa Pokémon'),
        centerTitle: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_loading)
                const CircularProgressIndicator()
              else ...[
                if (_imageUrl != null)
                  Image.network(
                    _imageUrl!,
                    height: 150,
                  ),
                const SizedBox(height: 16),
                Text(
                  _name ?? 'Nenhum Pokémon carregado',
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _loading ? null : _getRandomPokemon,
                child: const Text('Sortear Pokémon'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
